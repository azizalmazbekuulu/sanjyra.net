$( document ).ready(function()
{
    CKEDITOR.replace('description_short');
    CKEDITOR.replace('description');
    CKEDITOR.replace('info');
});