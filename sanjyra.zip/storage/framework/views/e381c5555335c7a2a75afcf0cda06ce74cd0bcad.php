<?php $__env->startSection('content'); ?>
    
<div class="container">
    
    <?php $__env->startComponent('admin.components.breadcrumb'); ?>
        <?php $__env->slot('title'); ?> Ысымдардын тизмеси <?php $__env->endSlot(); ?>
        <?php $__env->slot('parent'); ?> Башкы бет <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Ысымдар <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <hr>

    <a href="<?php echo e(route('admin.name.create')); ?>" class="btn btn-primary float-right"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Ысым түзүү</a>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Ысым</th>
                <th>Аял - Эркек</th>
                <th class="text-right">Аракет</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($name->name); ?></td>
                    <td><?php if($name->male_female): ?>
                        Эркек ысымы
                    <?php else: ?>
                        Аял ысымы
                    <?php endif; ?></td>
                    <td class="text-right">
                        <form onsubmit="if(confirm('Өчүрүү керекпи?')){ return true }else{ return false }" action="<?php echo e(route('admin.name.destroy', $name)); ?>" method="post">
                            <input type="hidden" name="_method" value="DELETE">
                            <?php echo e(csrf_field()); ?>

                            <a class="btn btn-default" href="<?php echo e(route('admin.name.edit', $name)); ?>"><i class="fas fa-edit"></i></a>
                            <button type="submit" class="btn"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center">Маалыматтар жок</td>
                </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3">
                    <ul class="pagination float-right">
                        <?php echo e($names->links()); ?>

                    </ul>
                </td>
            </tr>
        </tfoot>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/admin/names/index.blade.php ENDPATH**/ ?>