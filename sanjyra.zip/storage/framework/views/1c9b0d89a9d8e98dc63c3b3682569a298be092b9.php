<?php
$active_man = $man;
if ($father->id == $active_man_id)
    $active_man = $father;
if (isset($active_woman_id))
    $active_woman = $active_man->kyzdary->find($active_woman_id);
?>
<?php $__env->startSection('content'); ?>
<div class="justify-content-center">
    <?php echo $__env->make('sanjyra.partials.tree', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="justify-content-center p-3">
    <?php echo $__env->make('sanjyra.partials.famous_people', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="row p-3">
    <?php echo $__env->make('sanjyra.partials.name', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sanjyra.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/sanjyra/home.blade.php ENDPATH**/ ?>