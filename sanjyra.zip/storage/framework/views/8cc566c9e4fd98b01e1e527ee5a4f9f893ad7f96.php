<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php $__env->startComponent('admin.components.breadcrumb'); ?>
            <?php $__env->slot('title'); ?> Ысымдарды оңдоо <?php $__env->endSlot(); ?>
            <?php $__env->slot('parent'); ?> Башкы бет <?php $__env->endSlot(); ?>
            <?php $__env->slot('active'); ?> Ысымдар <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
        <hr>
        <form action="<?php echo e(route('admin.name.update', $name)); ?>" method="post">
            <input type="hidden" name="_method" value="put">
            <?php echo e(csrf_field()); ?>


            
            <?php echo $__env->make('admin.names.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <input type="hidden" name="modified_by" value="<?php echo e(Auth::id()); ?>">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/admin/names/edit.blade.php ENDPATH**/ ?>