<h2><?php echo e($title); ?></h2>
<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e($parent); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e($active); ?></li>
</ol><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/sanjyra/components/breadcrumb.blade.php ENDPATH**/ ?>