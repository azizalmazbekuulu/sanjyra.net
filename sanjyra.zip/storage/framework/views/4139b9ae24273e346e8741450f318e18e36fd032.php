<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.men.partials.tree', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/admin/men/show.blade.php ENDPATH**/ ?>