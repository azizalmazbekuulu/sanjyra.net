<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php $__env->startComponent('admin.components.breadcrumb'); ?>
            <?php $__env->slot('title'); ?> Адамдарды оңдоо <?php $__env->endSlot(); ?>
            <?php $__env->slot('parent'); ?> Башкы бет <?php $__env->endSlot(); ?>
            <?php $__env->slot('active'); ?> Адамдар <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
        <hr>
        <?php
            $active_man = $man;
            if ($father->id == $active_man_id)
                $active_man = $father;
        ?>
        <div class="row">
            <div class="col-sm-6">
                <?php echo $__env->make('admin.men.partials.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <hr>
                <p class="text-primary">Маалыматтарды өзгөртүү:</p>
                <form 
                <?php if(isset($active_woman)): ?>
                    action="<?php echo e(route('admin.woman.update', $active_woman)); ?>"
                <?php else: ?>
                    <?php if($father->id == $active_man_id): ?>
                        action="<?php echo e(route('admin.man.update', $father)); ?>"
                    <?php else: ?>
                        action="<?php echo e(route('admin.man.update', $man)); ?>"
                    <?php endif; ?>
                <?php endif; ?>
                 method="post">
                    <input type="hidden" name="_method" value="put">
                    <?php echo e(csrf_field()); ?>


                    
                    <?php echo $__env->make('admin.men.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <input type="hidden" name="modified_by" value="<?php echo e(Auth::id()); ?>">
                </form>
            </div>
            <div class="col-sm-6 justify-content-center" style="padding: 30px;">
                <?php echo $__env->make('admin.men.partials.tree', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <hr>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/admin/men/edit.blade.php ENDPATH**/ ?>