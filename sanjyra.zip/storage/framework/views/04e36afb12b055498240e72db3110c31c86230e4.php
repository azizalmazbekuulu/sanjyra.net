<div class="col-sm-6">
    
</div>
<div class="col-sm-6">
    <ul class="list-group w-100">
        <span class="list-group-item">Көп кездешкен ысымдар</span>
    <?php $__currentLoopData = $common_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $common_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item d-flex justify-content-between align-items-center">
            <a href="<?php echo e(route('name-show', $common_name->name)); ?>">
                <h4><?php echo e($common_name->name); ?></h4>
            </a>
            <span class="badge badge-primary badge-pill"><?php echo e($common_name->name_count); ?></span>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/sanjyra/partials/name.blade.php ENDPATH**/ ?>