<?php $__env->startSection('content'); ?>
    
<div class="container">
    
    <?php $__env->startComponent('admin.components.breadcrumb'); ?>
        <?php $__env->slot('title'); ?>  <?php $__env->endSlot(); ?>
        <?php $__env->slot('parent'); ?> Башкы бет <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Эркек адамдар <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <hr>
    <?php
        $active_man = $man;
        if ($father->id == $active)
            $active_man = $father;
    ?>
    <?php echo $__env->make('admin.men.partials.tree', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/admin/men/index.blade.php ENDPATH**/ ?>