<div class="row">
    <span class="float-right">
        <table class="tree">
            <tbody>
                <tr>
                    <td>
                        <a class="btn btn-primary h-100 w-100" href="<?php echo e(route('man.man', $man->id)); ?>">
                            <?php echo e($man->name); ?>

                        </a>
                    </td>
                    <td>
                        <svg height="20" width="40">
                            <line x1="0" y1="10" x2="40" y2="10" style="stroke:rgb(255,0,0);stroke-width:2" />
                            Балдары:
                        </svg>
                    </td>
                </tr>
            </tbody>
        </table>
    </span>
    <span class="float-right">
        <table class="tree">
            <tbody>
                <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a class="btn btn-primary w-100 h-100" href="<?php echo e(route('man.man', $child->id)); ?>">
                            <?php echo e($child->name); ?>

                        </a>
                    </td>
                    <?php if($child->id == $grandchildren->first()->father_id): ?>
                        <td>
                            <svg height="20" width="40">
                                <line x1="0" y1="10" x2="40" y2="10" style="stroke:rgb(255,0,0);stroke-width:2" />
                                Балдары:
                            </svg>
                        </td>
                        <?php $grandlining = $child->kanchanchy_bala - 1; ?>
                    <?php else: ?>
                        <td></td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </span>
    <span class="float-right">
        <table class="tree">
            <tbody>
                <?php if(isset($grandlining)): ?>
                    <?php for($i = 0; $i < $grandlining; $i++): ?>
                        <tr>
                            <td><span class="btn">&nbsp;</span></td>
                        </tr>
                    <?php endfor; ?>
                <?php endif; ?>
                <?php $__currentLoopData = $grandchildren; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grandchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a class="btn btn-primary w-100 h-100" href="<?php echo e(route('man.man', $grandchild->id)); ?>">
                            <?php echo e($grandchild->name); ?>

                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </span>
</div><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/men/tree.blade.php ENDPATH**/ ?>