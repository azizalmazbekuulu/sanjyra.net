<div class="form-group">
    <label for="">Ысым</label>
    <input type="text" class="form-control" name="name" placeholder="Ысым" 
    <?php if(isset($active_woman)): ?>
        value="<?php echo e($active_woman->name ?? ''); ?>"  
    <?php else: ?>
        value="<?php echo e($active_man->name ?? ''); ?>" 
    <?php endif; ?>
    required>
</div>
<div class="form-group">
    <label for="">Энесинин IDси</label>
    <input type="text" class="form-control" name="mother_id" placeholder="Энесинин IDси"  
    <?php if(isset($active_woman)): ?>
        value="<?php echo e($active_woman->mother_id ?? ''); ?>"  
    <?php else: ?>
        value="<?php echo e($active_man->mother_id ?? ''); ?>" 
    <?php endif; ?>>
</div>
<div class="form-group">
    <label for="">Энесинин аты</label>
    <input type="text" class="form-control" name="mother_name" placeholder="Энесинин аты" <?php if(isset($active_woman)): ?>
        <?php if($active_woman->mother_id != 0): ?>
            value="<?php echo e($active_woman->mother()->first()->name ?? ''); ?>" readonly="readonly"
        <?php else: ?>
            value="<?php echo e($active_woman->mother_name ?? ''); ?>"
        <?php endif; ?>
    <?php else: ?>
        <?php if($active_man->mother_id != 0): ?>
            value="<?php echo e($active_man->mother()->first()->name ?? ''); ?>" readonly="readonly"
        <?php else: ?>
            value="<?php echo e($active_man->mother_name ?? ''); ?>"
        <?php endif; ?>
    <?php endif; ?>>
</div>
<div class="form-group">
    <label for="info">Маалымат</label>
    <textarea name="info" id="info">
        <?php if(isset($active_woman)): ?>
            <?php echo $active_woman->info ?? ''; ?>

        <?php else: ?>
            <?php echo $active_man->info ?? ''; ?>

        <?php endif; ?>
    </textarea>
</div>
<div class="form-group">
    <label for="">Категориялар</label>
    <select name="categories[]" class="form-control" multiple="multiple">
        <?php echo $__env->make('admin.articles.partials.categories', ['categories' => $categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </select>
</div>
<input type="hidden" name="father_id" value="<?php echo e($active_man->father_id); ?>">
<input type="hidden" name="uruusu" value="<?php echo e($active_man->uruusu); ?>">
<input type="hidden" name="level" value="<?php echo e($active_man->level); ?>">
<input type="hidden" name="kanchanchy_bala" value="<?php echo e($active_man->kanchanchy_bala); ?>">
<hr>
<input class="btn btn-primary" type="submit" value="Сактоо"><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/admin/men/partials/form.blade.php ENDPATH**/ ?>