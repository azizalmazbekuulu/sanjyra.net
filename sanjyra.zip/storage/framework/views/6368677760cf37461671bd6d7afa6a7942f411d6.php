<div class="row justify-content-center d-flex flex-nowrap p-3" style="overflow: auto;">
    <table class="tree">
        <tbody>
            <tr>
                <td>
                    <a class="btn font-weight-bold border border-dark rounded-pill
                    <?php if($father->id == $active_man_id): ?>
                        bg-success text-danger
                    <?php else: ?>
                        bg-primary text-white
                    <?php endif; ?>
                     w-100 h-100"
                     href="<?php echo e(route('man-show', $father)); ?>">
                        <?php echo e($father->name); ?>

                    </a>
                </td>
                <td>
                    <svg height="20" width="40">
                        <line x1="0" y1="10" x2="40" y2="10" style="stroke:rgb(0,0,0);stroke-width:2" />
                        Балдары:
                    </svg>
                </td>
            </tr>
        </tbody>
    </table>
    <table class="tree">
        <tbody>
            <?php $__currentLoopData = $father->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a class="btn font-weight-bold border border-dark rounded-pill 
                    <?php if($child->id == $active_man_id): ?>
                        bg-success text-danger
                    <?php else: ?>
                        bg-primary text-white
                    <?php endif; ?>
                     w-100 h-100"
                     href="<?php echo e(route('man-show', $child)); ?>">
                        <?php echo e($child->name); ?>

                    </a>
                </td>
                <?php if($child->bala_sany > 0 && $child->id == $man->id): ?>
                    <td>
                        <svg height="20" width="40">
                        <line x1="0" y1="10" x2="40" y2="10" style="stroke:rgb(0,0,0);stroke-width:2" />
                        Балдары:
                        </svg>
                    </td>
                    <?php $grandlining = $child->kanchanchy_bala - 1; ?>
                <?php else: ?>
                    <td></td>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <table class="tree">
        <tbody>
            <?php if(isset($grandlining)): ?>
                <?php for($i = 0; $i < $grandlining; $i++): ?>
                    <tr>
                        <td><span class="btn">&nbsp;</span></td>
                    </tr>
                <?php endfor; ?>
            <?php endif; ?>
            <?php if($man->bala_sany > 0): ?>
                <?php $__currentLoopData = $man->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grandchild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a class="btn bg-primary font-weight-bold text-white border border-dark rounded-pill w-100 h-100" href="<?php echo e(route('man-show', $grandchild)); ?>">
                            <?php echo e($grandchild->name); ?>

                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="card">
<div class="card-header">
    <?php if($father->id != $active_man->id): ?>
        <?php echo e($father->name); ?> уулу <?php echo e($active_man->name); ?>

    <?php else: ?>
        <?php echo e($active_man->name); ?>

    <?php endif; ?>
</div>
<div class="card-body">
<dl class="row">
    <?php if($active_man->uruusu != ''): ?>
        <dt class="col-sm-2">Уруусу</dt>
        <dd class="col-sm-10"><?php echo e($active_man->uruusu); ?></dd>
    <?php endif; ?>
    <?php if($active_man->mother_name != '' || $active_man->mother_id != 0): ?>
        <dt class="col-sm-2">Энеси</dt>
        <dd class="col-sm-10">
            <?php if($active_man->mother_id != 0): ?>
                <a href="<?php echo e(route('woman-show', $active_man->mother)); ?>">
                    <?php echo e($active_man->mother->name); ?>

                </a>
            <?php else: ?>
                <?php echo e($active_man->mother_name); ?>

            <?php endif; ?>
        </dd>
    <?php endif; ?>
    <?php if($active_man->kyzdary->first() != null): ?>
        <dt class="col-sm-2">Кыздары</dt>
        <dd class="col-sm-10">
            <?php $__currentLoopData = $active_man->kyzdary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kyzy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="btn font-weight-bold border border-dark 
                <?php if(isset($active_woman) && $kyzy->id == $active_woman->id): ?>
                    bg-success text-danger
                <?php else: ?>
                    bg-primary text-white
                <?php endif; ?>
                "
                href="<?php echo e(route('woman-show', $kyzy)); ?>">
                    <?php echo e($kyzy->name); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($active_woman)): ?>
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-header"><?php echo e($active_man->name); ?> кызы <?php echo e($active_woman->name); ?></h6>
                        <dl class="row pt-2">
                        <?php if($active_woman->mother_name != '' || $active_woman->mother_id != 0): ?>
                            <dt class="col-sm-2">Энеси</dt>
                            <dd class="col-sm-10">
                                <?php if($active_woman->mother_id != 0): ?>
                                    <a href="<?php echo e(route('woman-show', $active_woman->mother)); ?>">
                                        <?php echo e($active_woman->mother->name); ?>

                                    </a>
                                <?php else: ?>
                                    <?php echo e($active_woman->mother_name); ?>

                                <?php endif; ?>
                            </dd>
                        <?php endif; ?>
                        <?php if($active_woman->uuldary->first() != null): ?>
                            <dt class="col-sm-2">Балдары</dt>
                            <dd class="col-sm-10">
                                <?php $__currentLoopData = $active_woman->uuldary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uulu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="btn font-weight-bold border border-dark bg-primary text-white"
                                    href="<?php echo e(route('man-show', $uulu)); ?>">
                                        <?php echo e($uulu->name); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </dd>
                        <?php endif; ?>
                        <?php if($active_woman->categories()->first() != null): ?>
                            <dt class="col-sm-2">Категориялар</dt>
                            <dd class="list-group-item-text col-sm-10">
                                <?php echo e($active_woman->categories()->pluck('title')->implode(', ')); ?>

                            </dd>
                        <?php endif; ?>
                        <?php if($active_woman->info != ''): ?>
                            <dt class="col-sm-2">Маалымат</dt>
                            <dd class="col-sm-10"><?php echo $active_woman->info; ?></dd>
                        <?php endif; ?>
                        </dl>
                    </div>
                </div>
            <?php endif; ?>
        </dd>
    <?php endif; ?>
    <?php if($active_man->categories()->first() != null): ?>
        <dt>Категориялар</dt>
        <dd class="list-group-item-text">
            <?php echo e($active_man->categories()->pluck('title')->implode(', ')); ?>

        </dd>
    <?php endif; ?>
    <?php if($active_man->info != '' && !isset($active_woman_id)): ?>
        <dt class="col-sm-2">Маалымат</dt>
        <dd class="col-sm-10"><?php echo $active_man->info; ?></dd>
    <?php endif; ?>
</dl>
</div></div><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/sanjyra/partials/tree.blade.php ENDPATH**/ ?>