<div class="container border pt-3 bg-secondary text-light">
<?php if($active_man->bala_sany == 0 && $active_man->kyzdary->first() == null): ?>
    <form onsubmit="if(confirm('Уулду өчүрүү керекпи?')){ return true }else{ return false }" action="<?php echo e(route('admin.man.destroy', $active_man)); ?>" method="post">
        <input type="hidden" name="_method" value="DELETE">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-danger"><i class="fa fa-trash-o" aria-hidden="true"></i> Уулду өчүрүү</button>
    </form>
<?php endif; ?>
<?php if(isset($active_woman_id)): ?>
    <form onsubmit="if(confirm('Кызды өчүрүү керекпи?')){ return true }else{ return false }" action="<?php echo e(route('admin.woman.destroy', $active_woman)); ?>" method="post">
        <input type="hidden" name="_method" value="DELETE">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-danger"><i class="fa fa-trash-o" aria-hidden="true"></i> Кызды өчүрүү</button>
    </form>
<?php endif; ?>
<form action="<?php echo e(route('admin.man.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <input class="btn btn-primary float-right ml-3 border border-success" type="submit" value="Уул кошуу">
        <input formaction="<?php echo e(route('admin.woman.store')); ?>" class="btn btn-primary float-right ml-3 border border-success" type="submit" value="Кыз кошуу">
        <label for="name">Бала кошуу</label>
        <input type="text" class="form-control" name="name" id="name" placeholder="Баланын ысымы">
    </div>
    <input type="hidden" name="father_id" value="<?php echo e($active_man->id); ?>">
    <input type="hidden" name="level" value="<?php echo e($active_man->level); ?>">
    <input type="hidden" name="uruusu" value="<?php echo e($active_man->uruusu); ?>">
    <input type="hidden" name="kanchanchy_bala" value="<?php echo e($active_man->bala_sany); ?>">
    <input type="hidden" name="created_by" value="<?php echo e(Auth::id()); ?>">
</form>
</div><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/admin/men/partials/create.blade.php ENDPATH**/ ?>