<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php $__env->startComponent('admin.components.breadcrumb'); ?>
            <?php $__env->slot('title'); ?> Эркек адамдарды кошуу <?php $__env->endSlot(); ?>
            <?php $__env->slot('parent'); ?> Башкы бет <?php $__env->endSlot(); ?>
            <?php $__env->slot('active'); ?> Эркек адамдар <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
        <hr>
        <div class="col-sm-4">
            <form action="<?php echo e(route('admin.man.store')); ?>" method="post">
                <?php echo e(csrf_field()); ?>


                
                <?php echo $__env->make('admin.men.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </form>
        </div>
        <div class="col-sm-8">
            <?php echo $__env->make('admin.men.partials.tree', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/admin/men/create.blade.php ENDPATH**/ ?>