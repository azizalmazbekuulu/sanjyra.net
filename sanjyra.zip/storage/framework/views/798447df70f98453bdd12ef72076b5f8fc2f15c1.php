<?php $__env->startSection('content'); ?>
    
<div class="container">
    
    <?php $__env->startComponent('sanjyra.components.breadcrumb'); ?>
        <?php $__env->slot('title'); ?> Ысымдар тизмеси <?php $__env->endSlot(); ?>
        <?php $__env->slot('parent'); ?> Башкы бет <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Ысымдар <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <hr>
    <table class="table table-striped text-center">
        <thead>
            <tr>
                <th>Аталышы</th>
                <th>Аныктамасы</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($name->name); ?></td>
                    <td><?php echo e($name->description); ?>loremalafkjsd l;fasl;f sdl;fj l;asdkjf dj l;asdkfj l;asdkjf las;dkj f;laskflsk fl;ksdjf l;sf asjd flsdj ;alsdkjf l;asdj fl;askdj f;laskdj fl;sadj fls flsd lfsald fjsald fasldjf sladj flsadj flsd fsd fls dalfalsd flasdf asdlfkj asdlfsdl f alsdfl sjadlsdfl</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="2" class="text-center">Ысымдар жок</td>
                </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="2">
                    <ul class="pagination float-right">
                        <?php echo e($names->links()); ?>

                    </ul>
                </td>
            </tr>
        </tfoot>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/sanjyra/name.blade.php ENDPATH**/ ?>