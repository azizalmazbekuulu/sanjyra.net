<div class="form-group">
    <label for="">Статус</label>
    <select name="published" class="form-control">
        <?php if(isset($category->id)): ?>
            <option value="0" <?php if($category->published == 0): ?> selected="" <?php endif; ?>>Жарыяланган эмес</option>
            <option value="1" <?php if($category->published == 1): ?> selected="" <?php endif; ?>>Жарыяланган</option>
        <?php else: ?>
            <option value="0">Жарыяланган эмес</option>
            <option value="1">Жарыяланган</option>
        <?php endif; ?>
    </select>
</div>
<div class="form-group">
    <label for="">Аталыш</label>
    <input type="text" class="form-control" name="title" placeholder="Категориянын аталышы" <?php if(isset($category->title)): ?> value="<?php echo e($category->title); ?>"
            <?php else: ?> value=""
            <?php endif; ?> required>
</div>
<div class="form-group">
    <label for="">Slug</label>
    <input type="text" class="form-control" name="slug" placeholder="Автоматтык түрдө түзүлөт" <?php if(isset($category->slug)): ?> value="<?php echo e($category->slug); ?>"
    <?php else: ?> value=""
    <?php endif; ?> readonly>
</div>
<div class="form-group">
    <label for="">Башкы категория</label>
    <select name="parent_id" class="form-control">
        <option value="0">-- башкы категориясыз --</option>
        <?php echo $__env->make('admin.categories.partials.categories', ['categories' => $categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </select>
</div>
<hr>
<input class="btn btn-primary" type="submit" value="Сактоо"><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/admin/categories/partials/form.blade.php ENDPATH**/ ?>