<?php $__env->startSection('content'); ?>
<?php if(isset($active_name)): ?>
    <dl class="row">
        <dt class="col-sm-4">
            <a href="<?php echo e(route('name')); ?>">
                <h4><?php echo e($active_name->name); ?></h4>
            </a>
        </dt>
        <dd class="col-sm-8">
            <p><?php echo $active_name->description; ?></p>
        </dd>
    </dl>
<?php endif; ?>
<div class="row p-3">
    <?php echo $__env->make('sanjyra.partials.name', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sanjyra.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/sanjyra/names/show.blade.php ENDPATH**/ ?>