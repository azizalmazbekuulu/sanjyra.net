<div class="form-group">
    <label for="">Статус</label>
    <select name="published" class="form-control">
        <?php if(isset($article->id)): ?>
            <option value="0" <?php if($article->published == 0): ?> selected="" <?php endif; ?>>Жарыяланган эмес</option>
            <option value="1" <?php if($article->published == 1): ?> selected="" <?php endif; ?>>Жарыяланган</option>
        <?php else: ?>
            <option value="0">Жарыяланган эмес</option>
            <option value="1">Жарыяланган</option>
        <?php endif; ?>
    </select>
</div>
<div class="form-group">
    <label for="">Аталыш</label>
    <input type="text" class="form-control" name="title" placeholder="Макаланын аталышы" <?php if(isset($article->title)): ?> value="<?php echo e($article->title); ?>"
            <?php else: ?> value=""
            <?php endif; ?> required>
</div>
<div class="form-group">
    <label for="">Slug (Окшошу жок маани)</label>
    <input type="text" class="form-control" name="slug" placeholder="Автоматтык түрдө түзүлөт" <?php if(isset($article->slug)): ?> value="<?php echo e($article->slug); ?>"
    <?php else: ?> value=""
    <?php endif; ?> readonly>
</div>
<div class="form-group">
    <label for="">Башкы категория</label>
    <select name="categories[]" class="form-control" multiple="multiple">
        <?php echo $__env->make('admin.articles.partials.categories', ['categories' => $categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </select>
</div>
<div class="form-group">
    <label for="description_short">Кыскача аныктама</label>
    <textarea name="description_short" id="description_short">
        <?php if(isset($article->description_short)): ?> <?php echo e($article->description_short); ?> <?php endif; ?>
    </textarea>
</div>
<div class="form-group">
    <label for="description">Толук аныктама</label>
    <textarea name="description" id="description">
        <?php if(isset($article->description)): ?> <?php echo e($article->description); ?> <?php endif; ?>
    </textarea>
</div>
<div class="form-group">
    <label for="">Мета аталыш</label>
    <input type="text" class="form-control" name="meta_title" placeholder="Мета аталыш" <?php if(isset($article->meta_title)): ?> value="<?php echo e($article->meta_title); ?>"
            <?php else: ?> value=""
            <?php endif; ?> required>
</div>
<div class="form-group">
    <label for="">Мета аныктама</label>
    <input type="text" class="form-control" name="meta_description" placeholder="Мета аныктама" <?php if(isset($article->meta_description)): ?> value="<?php echo e($article->meta_description); ?>"
            <?php else: ?> value=""
            <?php endif; ?> required>
</div>
<div class="form-group">
    <label for="">Ачкыч сөздөр</label>
    <input type="text" class="form-control" name="meta_keyword" placeholder="Ачкыч сөздөр" <?php if(isset($article->meta_keyword)): ?> value="<?php echo e($article->meta_keyword); ?>"
            <?php else: ?> value=""
            <?php endif; ?> required>
</div>
<hr>
<input class="btn btn-primary" type="submit" value="Сактоо"><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/admin/articles/partials/form.blade.php ENDPATH**/ ?>