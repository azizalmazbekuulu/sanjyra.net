<?php $__env->startSection('content'); ?>
    
<div class="container">
    
    <?php $__env->startComponent('admin.components.breadcrumb'); ?>
        <?php $__env->slot('title'); ?> Макалалар тизмеси <?php $__env->endSlot(); ?>
        <?php $__env->slot('parent'); ?> Башкы бет <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Макалалар <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

    <hr>

    <a href="<?php echo e(route('admin.article.create')); ?>" class="btn btn-primary float-right"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Макала түзүү</a>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Аталышы</th>
                <th>Жарыялоо</th>
                <th class="text-right">Аракет</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($article->title); ?></td>
                    <td><?php echo e($article->published); ?></td>
                    <td class="text-right">
                        <form onsubmit="if(confirm('Өчүрүү керекпи?')){ return true }else{ return false }" action="<?php echo e(route('admin.article.destroy', $article)); ?>" method="post">
                            <input type="hidden" name="_method" value="DELETE">
                            <?php echo e(csrf_field()); ?>

                            <a class="btn btn-default" href="<?php echo e(route('admin.article.edit', $article)); ?>"><i class="fas fa-edit"></i></a>
                            <button type="submit" class="btn"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center">Макалалар жок</td>
                </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3">
                    <ul class="pagination float-right">
                        <?php echo e($articles->links()); ?>

                    </ul>
                </td>
            </tr>
        </tfoot>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/admin/articles/index.blade.php ENDPATH**/ ?>