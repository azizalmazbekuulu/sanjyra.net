<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-2">
                <div class="card bg-secondary text-white">
                    <span class="card-header">Категорялар: <?php echo e($count_categories); ?></span>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="card bg-secondary text-white">
                    <span class="card-header">Макалалар: <?php echo e($count_articles); ?></span>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="card bg-secondary text-white">
                    <span class="card-header">Ысымдар: <?php echo e($count_names); ?></span>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card bg-secondary text-white">
                    <span class="card-header">Эркек адамдар: <?php echo e($count_men); ?></span>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card bg-secondary text-white">
                    <span class="card-header">Аял адамдар: <?php echo e($count_women); ?></span>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-4">
                <a href="<?php echo e(route('admin.name.create')); ?>" class="btn btn-block btn-primary">Ысым түзүү</a>
                Акыркы ысымдар:
                <?php $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('admin.name.edit', $name)); ?>" class="list-group-item">
                        <h4 class="list-group-item-heading"><?php echo e($name->name); ?></h4>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-sm-4">
                <a href="<?php echo e(route('admin.man.create')); ?>" class="btn btn-block btn-primary">Aдам кошуу</a>
                Акыркы кошулгандар:
                <?php $__currentLoopData = $men; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $man): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('admin.man.edit', $man)); ?>" class="list-group-item">
                        <h4 class="list-group-item-heading"><?php echo e($man->name); ?></h4>
                        <?php if($man->categories()->first() != null): ?>
                            <p class="list-group-item-text">
                                Категориялар: <?php echo e($man->categories()->pluck('title')->implode(', ')); ?>

                            </p>
                        <?php endif; ?>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-sm-4">
                <a href="<?php echo e(route('admin.man.create')); ?>" class="btn btn-block btn-primary">Адам кошуу</a>
                Акыркы кошулгандар:
                <?php $__currentLoopData = $women; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $woman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('admin.man.edit', $woman)); ?>" class="list-group-item">
                        <h4 class="list-group-item-heading"><?php echo e($woman->name); ?></h4>
                        <?php if($woman->categories()->first() != null): ?>
                            <p class="list-group-item-text">
                                Категориялар: <?php echo e($woman->categories()->pluck('title')->implode(', ')); ?>

                            </p>
                        <?php endif; ?>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-6">
                <a href="<?php echo e(route('admin.category.create')); ?>" class="btn btn-block btn-primary">Категория түзүү</a>
                Акыркы категориялар:
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('admin.category.edit', $category)); ?>" class="list-group-item">
                        <h4 class="list-group-item-heading"><?php echo e($category->title); ?></h4>
                        <p class="list-group-item-text">
                            Макалалардын саны: <?php echo e($category->articles()->count()); ?><br>
                            Адамдардындын саны: <?php echo e($category->men()->count()); ?>

                        </p>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-sm-6">
                <a href="<?php echo e(route('admin.article.create')); ?>" class="btn btn-block btn-primary">Макала түзүү</a>
                Акыркы макалалар:
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('admin.article.edit', $article)); ?>" class="list-group-item">
                        <h4 class="list-group-item-heading"><?php echo e($article->title); ?></h4>
                        <p class="list-group-item-text">
                            Категориялар: <?php echo e($article->categories()->pluck('title')->implode(', ')); ?>

                        </p>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <hr>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aziz/laravel-dev/sanjyra.net/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>